<?php 
    include_once ('utils/utils.php');

    $menuSelection = isset($_GET['menu']) ? $_GET['menu'] : 'main';

    switch($menuSelection) {
        case 'infantil':
        echo '<h1>'.getPath('/src/pages/infantil.php').'</h1>';
            require_once(getPath('/src/pages/infantil.php'));
            break;
            
        case 'main':
        default:
        echo '<h1>'.getPath('/src/pages/main.php').'</h1>';
            require_once(getPath('/src/pages/main.php'));
            break;

    }
 ?>
<!DOCTYPE html>
<html lang="en">
	<?php include($_SERVER['DOCUMENT_ROOT'].'/src/definitions/header.html'); ?>
  
  <body>
	<!-- Header -->
	<?php include($_SERVER['DOCUMENT_ROOT'].'/src/components/navbar.html'); ?>

	<!-- Footer -->
	<?php include($_SERVER['DOCUMENT_ROOT'].'/src/components/footer.html'); ?>

	<?php include($_SERVER['DOCUMENT_ROOT'].'/src/definitions/scriptsdef.html'); ?>

  </body>
</html>
<!-- https://startbootstrap.com/snippets/full-slider/ -->
<div class="header-content">
    <div id="carouselExampleIndicators" class="carousel" data-ride="carousel">
        <div class="carousel-item active" style="background-image: url('/images/main-image.jpg')">
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="container">
        <div id="relaod_test"></div>
    </div>
</div>